//
//  ViewController.swift
//  LocalNoification
//
//  Created by Mac on 19/05/18.
//  Copyright (c) 2018 TripaleA. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
var objButton : UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        objButton = UIButton.buttonWithType(.Custom) as? UIButton
        objButton.frame = CGRectMake(50, 300, 150, 40)
        objButton.setTitle("Click Me", forState: .Normal)
        objButton.setTitle("Button pressed", forState: .Highlighted)
        
        objButton.addTarget(self, action: "buttonIsPressed:", forControlEvents: .TouchDown)
        
        
    }
    
    
    @IBAction func ClickeAction(sender: AnyObject) {
        
        println("buttonIsPressed function called \(UIButton.description())")
        
        var localNotification = UILocalNotification()
        localNotification.fireDate = NSDate(timeIntervalSinceNow: 3)
        localNotification.alertBody = "This is local notification from Swift"
        localNotification.timeZone = NSTimeZone.localTimeZone()
        localNotification.repeatInterval = NSCalendarUnit.CalendarUnitMinute
        localNotification.userInfo = ["Important":"Data"];
        localNotification.soundName = UILocalNotificationDefaultSoundName
        localNotification.applicationIconBadgeNumber = 5
        localNotification.category = "Message"
        
        UIApplication.sharedApplication().scheduleLocalNotification(localNotification)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
   
    func buttonIsPressed(sender: UIButton) {
        println("buttonIsPressed function called \(UIButton.description())")
        
        var localNotification = UILocalNotification()
        localNotification.fireDate = NSDate(timeIntervalSinceNow: 1)
        localNotification.alertBody = "This is local notification from Swift"
        localNotification.timeZone = NSTimeZone.localTimeZone()
        localNotification.repeatInterval = NSCalendarUnit.CalendarUnitMinute
        localNotification.userInfo = ["Important":"Data"];
        localNotification.soundName = UILocalNotificationDefaultSoundName
        localNotification.applicationIconBadgeNumber = 5
        localNotification.category = "Message"
        
        UIApplication.sharedApplication().scheduleLocalNotification(localNotification)
    }


}

